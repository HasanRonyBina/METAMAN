Run in order (Python 3, numpy, scipy, pandas, matplotlib), from this folder:
  python3 analyze.py METAMAN2023.csv   # combined ANOVA, SE, LSD, H2 -> anova.pkl
  python3 stab.py METAMAN2023.csv      # Eberhart-Russell, Wricke, Shukla, Kang, GGE -> stab.pkl
  python3 figs.py                      # letters, Figure 1, Figure 2
  python3 mktables.py                  # Tables 3, 4, 6, 7, 8 -> tables.json
