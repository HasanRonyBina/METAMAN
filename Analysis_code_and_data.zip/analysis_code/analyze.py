import sys, numpy as np, pandas as pd
from scipy import stats
df=pd.read_csv(sys.argv[1])
traits=['GY','DTF','DTM','PH','TT','ET','PL','MILLING','HRR','GL','GB','LBR']
G=sorted(df.GEN.unique()); E=sorted(df.ENV.unique()); g,e,r=len(G),len(E),3
out={}
print("Bartlett GY:",stats.bartlett(*[df[df.ENV==x].GY for x in E]))
for t in traits:
    y=df[t]; gm=y.mean()
    SST=((y-gm)**2).sum()
    em=df.groupby('ENV')[t].mean(); gmn=df.groupby('GEN')[t].mean(); ge=df.groupby(['GEN','ENV'])[t].mean()
    rem=df.groupby(['ENV','REP'])[t].mean()
    SSE_=g*r*((em-gm)**2).sum(); SSR=g*((rem-rem.index.get_level_values(0).map(em).values)**2).sum()
    SSG=e*r*((gmn-gm)**2).sum()
    SSGE=r*sum((ge[(a,b)]-gmn[a]-em[b]+gm)**2 for a in G for b in E)
    SSe=SST-SSE_-SSR-SSG-SSGE
    df_={'E':e-1,'R':e*(r-1),'G':g-1,'GE':(g-1)*(e-1),'e':(g-1)*e*(r-1)}
    MS={'E':SSE_/2,'R':SSR/6,'G':SSG/4,'GE':SSGE/8,'e':SSe/24}
    F={'E':MS['E']/MS['R'],'G':MS['G']/MS['e'],'GE':MS['GE']/MS['e'],'GvGE':MS['G']/MS['GE']}
    p={'E':stats.f.sf(F['E'],2,6),'G':stats.f.sf(F['G'],4,24),'GE':stats.f.sf(F['GE'],8,24),'GvGE':stats.f.sf(F['GvGE'],4,8)}
    vg=(MS['G']-MS['GE'])/(r*e); vge=(MS['GE']-MS['e'])/r
    H2=max(vg,0)/(max(vg,0)+max(vge,0)/e+MS['e']/(r*e))
    se=np.sqrt(MS['e']/(r*e)); lsd=stats.t.ppf(.975,24)*np.sqrt(2*MS['e']/(r*e))
    cv=np.sqrt(MS['e'])/gm*100
    out[t]=dict(MS=MS,F=F,p=p,SS=dict(E=SSE_,G=SSG,GE=SSGE,T=SST),H2=H2,se=se,lsd=lsd,cv=cv,gmn=gmn,em=em,ge=ge)
    print(f"\n== {t}: mean {gm:.2f} CV {cv:.2f} SE {se:.3f} LSD {lsd:.3f} H2 {H2:.2f} vg {vg:.4f} vge {vge:.4f}")
    for k in ['E','R','G','GE','e']: print(f"  {k}: df {df_[k]} MS {MS[k]:.4f}", f"F {F.get(k,np.nan):.2f} p {p.get(k,np.nan):.4g}" if k in F else "")
    print(f"  G vs GE: F {F['GvGE']:.2f} p {p['GvGE']:.4g}; %SS E {100*SSE_/SST:.1f} G {100*SSG/SST:.1f} GE {100*SSGE/SST:.1f}")
    print("  gen means", gmn.round(2).to_dict()); print("  env means", em.round(2).to_dict())
pd.to_pickle(out,'anova.pkl')
