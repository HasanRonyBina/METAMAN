import sys, numpy as np, pandas as pd, itertools
from scipy import stats
df=pd.read_csv(sys.argv[1]); A=pd.read_pickle('anova.pkl')
Y=df.groupby(['GEN','ENV']).GY.mean().unstack(); print(Y.round(2))
G=Y.index; p,q=Y.shape; r=3; MSe=A['GY']['MS']['e']
gm=Y.values.mean(); em=Y.mean(0); I=em-gm
res=[]
for gname in G:
    y=Y.loc[gname]; b=((y-y.mean())*I).sum()/(I**2).sum()
    dev=y-y.mean()-b*I; sd=(dev**2).sum()/(q-2); s2d=sd-MSe/r
    Fsd=sd/(MSe/r); psd=stats.f.sf(Fsd,q-2,24)
    seb=np.sqrt(sd/(I**2).sum()); tb=(b-1)/seb; pb=2*stats.t.sf(abs(tb),q-2)
    R2=1-(dev**2).sum()/((y-y.mean())**2).sum()
    W=((y-y.mean()-em+gm)**2).sum()
    res.append(dict(G=gname,Yi=y.mean(),CV=y.std(ddof=1)/y.mean()*100,b=b,pb=pb,s2d=s2d,psd=psd,R2=R2,W=W))
R=pd.DataFrame(res).set_index('G'); SW=R.W.sum()
R['sig']=(p*(p-1)*R.W-SW)/((p-1)*(p-2)*(q-1))
# Shukla F test: sig / (MSe/r)
R['psig']=stats.f.sf(R.sig/(MSe/r),q-1,24)
R['YS']=R.Yi.rank()+R.sig.rank(ascending=False)
print(R.round(3))
# GGE
X=Y.values-Y.values.mean(0); U,S,Vt=np.linalg.svd(X,full_matrices=False)
print("sing vals",S.round(3),"pct",(100*S**2/(S**2).sum()).round(2))
# genotype-focused scores
gs=U[:,:2]*S[:2]; es=Vt[:2].T
aec=es.mean(0); aec/=np.linalg.norm(aec)
proj=gs@aec; orth=gs@np.array([-aec[1],aec[0]])
print("AEC abscissa (genotype-focused):",dict(zip(G,proj.round(3))),"\northo:",dict(zip(G,np.abs(orth).round(3))))
# environment focused
es2=Vt[:2].T*S[:2]; avg=es2.mean(0)
for i,en in enumerate(Y.columns):
    v=es2[i]; ang=np.degrees(np.arccos(v@avg/np.linalg.norm(v)/np.linalg.norm(avg)))
    print(en,"vec len",round(np.linalg.norm(v),3),"angle to AEA",round(ang,1))
# ideal genotype distance (genotype focused)
ideal=aec*proj.max(); print("dist to ideal", dict(zip(G,np.linalg.norm(gs-ideal,axis=1).round(3))))
print("best per env:",Y.idxmax().to_dict())
# symmetrical which-won-where on 2D
gss=U[:,:2]*np.sqrt(S[:2]); ess=Vt[:2].T*np.sqrt(S[:2])
print("2D-predicted winner:",{en:G[np.argmax(gss@ess[i])] for i,en in enumerate(Y.columns)})
pd.to_pickle(dict(R=R,Y=Y,U=U,S=S,Vt=Vt),'stab.pkl')
# HRR by env
print(df.groupby(['GEN','ENV']).HRR.mean().unstack().round(2))
