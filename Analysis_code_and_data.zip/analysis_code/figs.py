import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
from scipy.spatial import ConvexHull
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
df=pd.read_csv('METAMAN2023.csv'); A=pd.read_pickle('anova.pkl')
lab={'G1':'G1','G2':'G2','G3':'G3','G4':'G4','G5':'G5\n(check)'}
def letters(means,lsd):
    m=means.sort_values(ascending=False); names=list(m.index); groups=[]
    for i,n in enumerate(names):
        grp={x for x in names if abs(m[n]-m[x])<lsd and m[x]<=m[n]}|{n}
        if not any(grp<=g for g in groups): groups.append(grp)
    out={n:''.join(chr(97+k) for k,g in enumerate(groups) if n in g) for n in names}
    return out
LET={t:letters(A[t]['gmn'],A[t]['lsd']) for t in A}
pd.to_pickle(LET,'letters.pkl')
for t in A: print(t, LET[t])
# Figure 1
q=[('MILLING','Brown rice recovery (%)'),('HRR','Head brown rice recovery (%)'),('GL','Grain length (mm)'),('GB','Grain breadth (mm)'),('LBR','Length-to-breadth ratio')]
fig,axs=plt.subplots(1,5,figsize=(11,2.9))
for ax,(t,yl),pl in zip(axs,q,'abcde'):
    m=A[t]['gmn']; se=A[t]['se']; G=list(m.index)
    ax.bar(range(5),m.values,width=.6,color='#5a6e7f',yerr=se,capsize=2,error_kw={'lw':.8})
    lo=0
    ax.set_ylim(lo, max(m.values+se)*1.10)
    if A[t]['p']['G']<0.05:
        for i,g in enumerate(G): ax.text(i,m[g]+se+(ax.get_ylim()[1]-lo)*.02,LET[t][g],ha='center',fontsize=8)
    ax.set_xticks(range(5)); ax.set_xticklabels([lab[g] for g in G],fontsize=7.5)
    ax.set_ylabel(yl); ax.set_title(f'({pl})  H² = {A[t]["H2"]:.2f}'+('' if A[t]['p']['G']<0.05 else ', G ns'),fontsize=9,loc='left')
fig.tight_layout(); fig.savefig('Figure1.png',dpi=600); fig.savefig('Figure1.tif',dpi=600)
# Figure 2 GGE
Y=df.groupby(['GEN','ENV']).GY.mean().unstack(); G=list(Y.index); Ev=['E1','E2','E3']
X=Y.values-Y.values.mean(0); U,S,Vt=np.linalg.svd(X,full_matrices=False)
pc=100*S**2/(S**2).sum(); xl=f'PC1 ({pc[0]:.2f}%)'; yl=f'PC2 ({pc[1]:.2f}%)'
def sc(f):
    return U[:,:2]*S[:2]**f, Vt[:2].T*S[:2]**(1-f)
fig,axs=plt.subplots(2,2,figsize=(8,8))
GC='#1f2d3a'; EC='#b8452b'
def base(ax,gs,es,title):
    ax.axhline(0,color='#bbb',lw=.6); ax.axvline(0,color='#bbb',lw=.6)
    ax.scatter(gs[:,0],gs[:,1],s=22,color=GC,zorder=3)
    for i,g in enumerate(G): ax.annotate(g,gs[i],xytext=(4,4),textcoords='offset points',color=GC,fontsize=8.5)
    for i,e in enumerate(Ev):
        ax.annotate('',es[i],(0,0),arrowprops=dict(arrowstyle='->',color=EC,lw=1))
        ax.annotate(e,es[i],xytext=(4,-10),textcoords='offset points',color=EC,fontsize=8.5,fontweight='bold')
    ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(title,loc='left',fontsize=9.5); ax.set_aspect('equal','datalim')
# (a) mean vs stability genotype-focused
gs,es=sc(1); a=es.mean(0); a/=np.linalg.norm(a); ax=axs[0,0]; base(ax,gs,es,'(a) Mean performance vs stability')
L=np.abs(gs).max()*1.3; ax.plot([-L*a[0],L*a[0]],[-L*a[1],L*a[1]],color='#444',lw=.8); ax.plot([-L*a[1],L*a[1]],[L*a[0],-L*a[0]],color='#444',lw=.6,ls='--'); ax.annotate('',L*a,L*.8*a,arrowprops=dict(arrowstyle='->',color='#444'))
for i in range(5):
    p=(gs[i]@a)*a; ax.plot([gs[i,0],p[0]],[gs[i,1],p[1]],ls=':',color='#666',lw=.8)
# (b) ranking vs ideal
ax=axs[0,1]; base(ax,gs,es,'(b) Ranking relative to the ideal genotype')
proj=gs@a; ideal=a*proj.max()
ax.plot([-L*a[0],L*a[0]],[-L*a[1],L*a[1]],color='#444',lw=.8)
ax.scatter(*ideal,marker='*',s=120,color='#444',zorder=4); ax.annotate('Ideal',ideal,xytext=(-8,8),textcoords='offset points',fontsize=8)
for rr in np.linspace(.4,2.4,6): ax.add_patch(plt.Circle(ideal,rr,fill=False,color='#ccc',lw=.6))
# (c) discrimination vs representativeness env-focused
gs0,es0=sc(0); ax=axs[1,0]; base(ax,gs0,es0,'(c) Discrimination vs representativeness')
av=es0.mean(0); av/=np.linalg.norm(av); L2=np.abs(es0).max()*1.3
ax.plot([0,L2*av[0]],[0,L2*av[1]],color='#444',lw=.8); ax.annotate('AEA',L2*av,fontsize=8)
for rr in [.5,1,1.5]: ax.add_patch(plt.Circle((0,0),rr,fill=False,color='#ddd',lw=.6))
# (d) which-won-where symmetric
gs1,es1=sc(.5); ax=axs[1,1]; base(ax,gs1,es1,'(d) Which-won-where')
h=ConvexHull(gs1); vtx=h.vertices; P=gs1[np.r_[vtx,vtx[0]]]; ax.plot(P[:,0],P[:,1],color='#444',lw=.9)
R=np.abs(np.r_[gs1,es1]).max()*1.6
sect={}
for k in range(len(vtx)):
    p1,p2=gs1[vtx[k]],gs1[vtx[(k+1)%len(vtx)]]; d=p2-p1; n=np.array([-d[1],d[0]]); 
    t=-(p1@d)/(d@d); foot=p1+t*d  # perpendicular from origin to edge line
    if np.linalg.norm(foot)>1e-9: ax.plot([0,foot[0]/np.linalg.norm(foot)*R],[0,foot[1]/np.linalg.norm(foot)*R],ls='--',color='#888',lw=.8)
win={e:G[int(np.argmax(gs1@es1[i]))] for i,e in enumerate(Ev)}; print('winners (biplot):',win,'vertices',[G[v] for v in vtx])
for ax in axs.flat: ax.set_xlim(ax.get_xlim()); 
fig.tight_layout(); fig.savefig('Figure2.png',dpi=600); fig.savefig('Figure2.tif',dpi=600)
# env correlation
C=np.corrcoef(X.T); print('env corr',C.round(2))
