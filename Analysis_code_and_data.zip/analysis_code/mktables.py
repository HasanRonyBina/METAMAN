import pandas as pd, numpy as np, json, re
A=pd.read_pickle('anova.pkl'); St=pd.read_pickle('stab.pkl'); L=pd.read_pickle('letters.pkl')
df=pd.read_csv('METAMAN2023.csv')
def star(p): return '***' if p<.001 else '**' if p<.01 else '*' if p<.05 else ' ns'
names={'G1':'G1 (R-30-1-1)','G2':'G2 (B-32-2-3)','G3':'G3 (B-32-3-4)','G4':'G4 (B-33-1-2)','G5':'G5 (BRRI dhan49, check)'}
lab={'GY':'GY','DTF':'DTF','DTM':'DTM','PH':'PH','TT':'TT','ET':'ET','PL':'PL','MILLING':'BRR','HRR':'HBRR','GL':'GL','GB':'GB','LBR':'LBR'}
def f(x): return f"{x:.2f}" if x<1000 else f"{x:.1f}"
T={}
rows=[]
for t,a in A.items():
    MS,p,SS=a['MS'],a['p'],a['SS']
    rows.append([lab[t],f(MS['E'])+star(p['E']),f(MS['R']),f(MS['G'])+star(p['G']),f(MS['GE'])+star(p['GE']),f(MS['e']),
      f"{100*SS['E']/SS['T']:.1f} / {100*SS['G']/SS['T']:.1f} / {100*SS['GE']/SS['T']:.1f}",f"{a['cv']:.2f}",f"{a['H2']:.2f}"])
T['T3']=[["Trait","E (df 2)","R(E) (df 6)","G (df 4)","G × E (df 8)","Error (df 24)","% SS E / G / G×E","CV (%)","H²"],rows,[700,1100,800,1100,1100,1150,1560,650,600]]
R=St['R']; Y=St['Y']; s4=[]
for g in R.index:
    r=R.loc[g]
    s4.append([names[g]]+[f"{Y.loc[g,e]:.2f}" for e in Y.columns]+[f"{r.Yi:.2f} {L['GY'][g]}",f"{r.CV:.2f}",f"{r.b:.2f}"+('†' if r.pb<.05 else ''),f"{r.R2:.2f}",
      f"{max(r.s2d,0):.2f}"+star(r.psd).replace(' ns',''),f"{r.W:.2f}",f"{r.sig:.2f}"+star(r.psig).replace(' ns',''),f"{int(r.YS)}"+('+' if r.YS>R.YS.mean() else '')])
em=Y.mean(0)
s4.append(["Site mean / overall mean"]+[f"{em[e]:.2f}" for e in Y.columns]+[f"{R.Yi.mean():.2f}",f"{R.CV.mean():.2f}","1.00","",f"{R.s2d.clip(lower=0).mean():.2f}",f"{R.W.mean():.2f}",f"{R.sig.mean():.2f}",f"{R.YS.mean():.2f}"])
s4.append(["SE (±) / LSD (0.05)","","","",f"{A['GY']['se']:.2f} / {A['GY']['lsd']:.2f}","","","","","","",""])
T['T4']=[["Genotype","E1","E2","E3","Yi","CVi","bi","R²","s²di","Wi²","σ²i","YSi"],s4,[1900,560,560,560,850,680,620,560,820,600,820,560]]
tr=['DTF','DTM','PH','TT','ET','PL']; s6=[]
for g in R.index: s6.append([names[g]]+[f"{A[t]['gmn'][g]:.2f} {L[t][g]}" for t in tr])
s6.append(["SE (±)"]+[f"{A[t]['se']:.2f}" for t in tr]); s6.append(["LSD (0.05)"]+[f"{A[t]['lsd']:.2f}" for t in tr]); s6.append(["H²"]+[f"{A[t]['H2']:.2f}" for t in tr])
T['T6']=[["Genotype","DTF","DTM","PH (cm)","TT","ET","PL (cm)"],s6,[2300,1050,1100,1150,1000,1000,1100]]
from scipy import stats
tr7=['GY','DTF','DTM','PH','TT','ET','PL']; Rd=df.copy()
for t in tr7: Rd[t]=df[t]-df.groupby('ENV')[t].transform('mean')
s7=[]
for i in range(1,7):
    row=[tr7[i]]
    for j in range(6):
        if j<i:
            r,_=stats.pearsonr(Rd[tr7[i]],Rd[tr7[j]]); tt=r*np.sqrt(41/(1-r*r)); p=2*stats.t.sf(abs(tt),41)
            row.append(f"{r:.2f}".replace('-','−')+('**' if p<.01 else '*' if p<.05 else ''))
        else: row.append("")
    s7.append(row)
T['T7']=[["","GY","DTF","DTM","PH","TT","ET"],s7,[1200,1100,1100,1100,1100,1100,1100]]
q=['MILLING','HRR','GL','GB','LBR']; M=df.groupby('GEN')[q].mean(); Z=(M-M.mean())/M.std(ddof=1)
U,S,Vt=np.linalg.svd(Z.values,full_matrices=False); sc=U[:,:2]*S[:2]; pct=100*S**2/(S**2).sum()
s8=[[names[g],f"{sc[i,0]:.3f}".replace('-','−'),f"{sc[i,1]:.3f}".replace('-','−')] for i,g in enumerate(M.index)]
s8.append(["Variation explained (%)",f"{pct[0]:.2f}",f"{pct[1]:.2f}"])
tn={'MILLING':'Brown rice recovery','HRR':'Head brown rice recovery','GL':'Grain length','GB':'Grain breadth','LBR':'Length-to-breadth ratio'}
for c in q: s8.append([f"r with {tn[c]}"]+[f"{np.corrcoef(Z[c],U[:,k])[0,1]:.2f}".replace('-','−') for k in range(2)])
T['T8']=[["Genotype / trait","PCo1","PCo2"],s8,[3600,1500,1500]]
json.dump(T,open('tables.json','w'),ensure_ascii=False,indent=0)
print(json.dumps(T['T4'][1][:2],ensure_ascii=False)); print(T['T8'][1][:3])
